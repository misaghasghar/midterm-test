/* 
 Filename: db.js
 Author: Misagh Asghari 
 Student ID = 301239798
 Web App Name: Midterm Test
 */
module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb+srv://misaghasghari:Jordanagh2244@bookdb.hhahnv3.mongodb.net/?retryWrites=true&w=majority"
};
